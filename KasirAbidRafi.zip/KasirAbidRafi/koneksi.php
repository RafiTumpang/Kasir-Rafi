<?php
$server="localhost";
$username="root";
$password="";
$db="kasir_rafi";

$koneksi=new mysqli("$server","$username","$password","$db");
?>