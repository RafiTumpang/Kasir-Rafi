<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>

<body>
    <table class="table table-dark">
        <thead>
            <tr>
                <th scope="col">Penjualan ID</th>
                <th scope="col">TanggalPenjualan</th>
                <th scope="col">TotalHarga</th>
            </tr>
        </thead>

        <?
        include "koneksi.php";
        $tampil = "";
        if (isset($_POST['cari'])) {
        $pilih = $_POST['pilih'];
        $tekscari = $_POST['tekscari'];
        $tampil = mysqli_query($koneksi, "select * from penjualan where $pilih like '%$tekscari%'");
        }
        else{
        $tampil = mysqli_query($koneksi, "select * from penjualan");
        }
        foreach ($tampil as $row){
        ?>


        <tbody style="background-color:#FFFFFF">
            <tr>
                <td></td>
                <td><?php echo "$row[PenjualanID]"; ?></td>
                <td><?php echo "$row[TanggalPenjualan]"; ?></td>
                <td><?php echo "$row[TotalHarga]"; ?></td>

        </tbody>
    </table>
</body>

</html>